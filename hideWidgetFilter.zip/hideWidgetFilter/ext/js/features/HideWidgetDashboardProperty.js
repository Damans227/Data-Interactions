/**
 * Licensed Materials - Property of IBM
 *
 * IBM Cognos Products: Cognos Dashboard
 *
 * Copyright IBM Corp. 2020
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([], function( ) {
	'use strict';
	class HideWidgetDashboardProperty {
        constructor(options) {
            this.Properties = options.features['Properties'];

            options.features['Properties'].registerProvider(this);
        }

        getPropertyList () {
            return [{
                "id": "hideWidgetFilterDashboardProp",
                "defaultValue": false,
                "editor": {
                    "sectionId": "general.filters",
                    "uiControl": {
                        "type": "ToggleButton",
                        "label": "Hide widget indicators"
                    }
                }
            }]
        }

        getPropertyLayoutList () {
            return [{
                "type": "Section",
                "id": "filters",
                "label": "Filters",
                "position": 0
            }];
        }
    }

	return HideWidgetDashboardProperty;

});