/**
 * Licensed Materials - Property of IBM
 *
 * IBM Cognos Products: Cognos Dashboard
 *
 * Copyright IBM Corp. 2020
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([], function( ) {
	'use strict';
	class HideWidgetFilter {
        constructor(options) {
            this.dashboardAPI = options.features['Dashboard.API'];
            this.content = options.content;
            options.features['Properties'].registerProvider(this);

            this.content.on('change:property:hideWidgetFilterProp', () => this.changeFilterIcon());
            this.dashboardAPI.getCanvasWhenReady().then(canvas => {
                canvas.on('change:property:hideWidgetFilterDashboardProp', () => this.changeFilterIcon());
            })
        }

        getPropertyList () {
            return [{
                "id": "hideWidgetFilterProp",
                "defaultValue": 'default',
                "editor": {
                    "sectionId": "visualization.filter",
                    "uiControl": {
                        "type": "DropDown",
                        "label": "Hide widget indicator",
                        'ariaLabel': 'Type',
                        'options': [{
							'label': 'Default',
							'value': 'default'
						},{
							'label': 'Show Filter',
							'value': 'show'
						},{
							'label': 'Hide Filter',
							'value': 'hide'
						}]
                    }
                }
            }]
        }

        getPropertyLayoutList () {
            return [{
                "type": "Section",
                "id": "filter",
                "label": "Filters",
                "position": 0
            }];
        }

        changeFilterIcon () {
            switch(this.content.getPropertyValue('hideWidgetFilterProp')) {
                case "default":
                    if(this.dashboardAPI.getCanvas().getPropertyValue('hideWidgetFilterDashboardProp')) {
                        this.content.getFeature('ContentViewDOM').getNode().getElementsByClassName('dataWidgetIcon dataWidgetFilters')[0].style.display = "none"
                    } else {
                        this.content.getFeature('ContentViewDOM').getNode().getElementsByClassName('dataWidgetIcon dataWidgetFilters')[0].style.display = ""
                    }
                    break;

                case "show":
                    this.content.getFeature('ContentViewDOM').getNode().getElementsByClassName('dataWidgetIcon dataWidgetFilters')[0].style.display = ""
                    break;

                case "hide":
                    this.content.getFeature('ContentViewDOM').getNode().getElementsByClassName('dataWidgetIcon dataWidgetFilters')[0].style.display = "none"
                    break; 
            }
        }
    }

	return HideWidgetFilter;

});